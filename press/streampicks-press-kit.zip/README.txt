StreamPicks press kit — November 13, 2026

Updated painted card art across card faces, collection, Workshop, Arena moments and videos.
8 full-resolution images; 3 card faces; 3 videos; 5 brand assets; cover art; sharing cover and fact sheet.

Trailers: 47.9 seconds, landscape 1920x1080 and portrait 1080x1920, 60 fps.
Pack reveal: 8.75 seconds, 1080x1920, 60 fps.
See capture-sources.json for provenance.

Contact: hello@streampicks.app
Website: https://streampicks.app/press/
