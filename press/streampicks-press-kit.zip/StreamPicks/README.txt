STREAM PICKS MEDIA KIT — OCTOBER 20, 2026

Press: hello@streampicks.app
Player help: support@streampicks.app
Partnerships: partnerships@streampicks.app

Start with Fact sheet.txt for game facts, short and extended descriptions,
feature information, links, and screenshot notes.

Logos and characters/: original PNG assets for editorial coverage of StreamPicks.
Screenshots/: six full-resolution native app captures. Some use sample accounts
and promotional display names. iOS status areas are cropped. Seasonal themes
may appear. capture-sources.json records the capture provenance.

Write the game name StreamPicks. Preserve logo colors and proportions.
Current media room: https://streampicks.app/press/
