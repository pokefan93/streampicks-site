STREAMPICKS — PRESS FACT SHEET
Updated October 20, 2026

Website: https://streampicks.app
Press room: https://streampicks.app/press/
Press contact: hello@streampicks.app
Player support: support@streampicks.app
Partnerships: partnerships@streampicks.app
Developer: Taylor's Tech Solutions LLC (solo developer)
Based in: Gans, Oklahoma, USA
Platforms: iPhone and Android
Price: Free to play, with optional purchases and StreamPicks+ subscription.
Current subscription pricing and regional terms are shown in the app.
Minimum player age: 13+. Store ratings vary by platform and region.
Genre: Collectible card battler and creator fantasy Leagues
App Store: https://apps.apple.com/app/id6760561274
Google Play: https://play.google.com/store/apps/details?id=app.streampicks.mobile

SHORT DESCRIPTION
StreamPicks is a free creator card game for iPhone and Android. Collect and evolve cards across 12 genres, build a deck for Arena battles, climb a 50-stage solo Career, and draft fantasy Leagues with friends. Customize your cards in the Workshop and browse your collection on the web.

FEATURES
Arena: Build a 20-card deck, evolve your creators, and time your Go Viral moment. Battle matched opponents, challenge friends, or practice in Solo.
Career: Climb from your first stream toward 10 million subscribers across 50 stages. Meet rivals, take on bosses, and chase three-star clears.
Leagues: Draft creators with friends and compete across a season. Real public creator performance powers fantasy matchups, with trades, waivers, and playoffs.
Aura Workshop: Make an owned card your own with cosmetic intros, auras, and metal treatments. Build a look to match the rest of your collection.
Trending Picks: Browse recent packs from other players, watch the shuffle, and pick a face-down card to add a surprise to your collection.
Web collection: Sign in at streampicks.app/account to browse your collection, inspect full cards, and build or edit decks tied to your game account.

ABOUT THE DEVELOPER
Taylor is a school district IT Director in Eastern Oklahoma who builds StreamPicks under Taylor's Tech Solutions LLC, around a full-time job and a family.

SCREENSHOTS
Real app captures. Collection, Workshop, Arena, and deck captures use a fictional sample account with promotional creator display names. iOS status areas are cropped. Screens may show seasonal themes.

EDITORIAL ASSETS
Use the supplied assets for coverage of StreamPicks. Preserve logo proportions and colors. Write the game name StreamPicks (one word, capital S and P).

INDEPENDENT GAME
StreamPicks is not affiliated with, endorsed by, or sponsored by YouTube, any creator, or any related brand. Creator names and likenesses are the property of their respective owners. Card stats are fictional and balanced for gameplay.
Creator takedown requests: https://streampicks.app/takedown/
Pack disclosures: https://streampicks.app/drop-rates/
