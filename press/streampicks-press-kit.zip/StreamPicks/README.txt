StreamPicks press media - October 21, 2026

Eight original screenshots, one holo pack-opening video, logos, characters, and fact sheet.

The five Android feature screenshots were captured in staging shell 1.50.0 with Ultra selected. The three iPhone Arena images were supplied by the developer; their graphics preset was not independently verified. The video uses the actual game screen rendered offline with Ultra graphics and promotional creator naming. See capture-sources.json for dimensions and provenance.

Screenshot originals are unaltered. Web previews hide phone system bars; full downloads preserve them. Use these assets when covering StreamPicks. Please preserve the logo.

Press: hello@streampicks.app
https://streampicks.app/press/
